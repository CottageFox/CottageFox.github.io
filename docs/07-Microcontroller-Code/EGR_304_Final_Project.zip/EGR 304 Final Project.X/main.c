#include "mcc_generated_files/system/system.h"

#include <builtins.h>
#include <stdio.h>

/*
    Main application
*/


int main(void)
{
    SYSTEM_Initialize();
    ADC_Initialize();
    UART1_Initialize();
    
    int result;
    
    ADC_ChannelSelect(ADC_CHANNEL_ANA0);
    
    for(uint8_t i = 0; i < 3; i++)
    {
        DEBUG_LED_SetHigh();
        __delay_ms(200);
        DEBUG_LED_SetLow();
        __delay_ms(200);
    }
        

    while(1)
    {
              
        
        ADC_ConversionStart();
        result = ADC_ConversionResultGet();
        
        printf("ADC Value = %d \r\n", result);
        
        if(result >= 500)
        {
            
            DEBUG_LED_SetHigh();
            __delay_ms(10);
            
            IO_RF4_SetLow();
            __delay_ms(10);
            
            IO_RF5_SetLow();
            __delay_ms(10);
        }
            
         
        if(result < 500)
            {
                DEBUG_LED_SetLow();
                __delay_ms(10);
                
                IO_RF4_SetHigh();
                __delay_ms(10);
            
                IO_RF5_SetHigh();
                __delay_ms(10);
            }
                
                
        
        
    } 
    
    return 0;
}